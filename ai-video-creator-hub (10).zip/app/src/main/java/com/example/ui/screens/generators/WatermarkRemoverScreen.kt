package com.example.ui.screens.generators

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

@Composable
fun WatermarkRemoverScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var videoFileUrl by remember { mutableStateOf("") }
    var watermarkPosition by remember { mutableStateOf("Bottom Right") }
    var isUserOwnedConfirmed by remember { mutableStateOf(false) }
    var isProcessing by remember { mutableStateOf(false) }
    var cleanedVideoResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("watermark_remover_screen")
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(DarkSurface)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("AI WATERMARK REMOVER", fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AccentGold)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("USER OWNED", fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.Black)
                    }
                }
                Text("Clean Watermarks & Logos from Your Own Rendered Videos", fontSize = 11.sp, color = AccentCyan)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF2E2954), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("REMOVE WATERMARK / LOGO", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AccentGold)
                Text("AI Inpainting cleanly erases watermarks while preserving video resolution.", fontSize = 10.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(12.dp))

                Text("Video File Source (MP4 URL or Upload Path):", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = videoFileUrl,
                    onValueChange = { videoFileUrl = it },
                    placeholder = { Text("e.g. Upload video file or paste MP4 link", color = Color.Gray, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = AccentCyan)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Watermark Position:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Bottom Right", "Top Right", "Bottom Left", "Auto Detect").forEach { pos ->
                        val isSel = watermarkPosition == pos
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) PrimaryPurple else Color(0xFF1E1A36))
                                .border(1.dp, if (isSel) AccentGold else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { watermarkPosition = pos }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(pos, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else Color.LightGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Legal ownership confirmation checkbox
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1E1A36))
                        .padding(8.dp)
                ) {
                    Checkbox(
                        checked = isUserOwnedConfirmed,
                        onCheckedChange = { isUserOwnedConfirmed = it },
                        colors = CheckboxDefaults.colors(checkedColor = AccentGold, checkmarkColor = Color.Black)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "I confirm that I own the copyright or have full rights to remove watermarks from this video content.",
                        fontSize = 10.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (!isUserOwnedConfirmed) {
                            Toast.makeText(context, "Please confirm that you own rights to this content", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isProcessing = true
                        viewModel.generateTextToVideo(
                            prompt = "Remove watermark and clean video inpainting for position $watermarkPosition",
                            durationSeconds = 15,
                            aspectRatio = "16:9",
                            onComplete = { success, msg, url ->
                                isProcessing = false
                                if (success) {
                                    cleanedVideoResult = "Cleaned Video (No Watermark): $url"
                                    Toast.makeText(context, "Watermark cleanly removed with AI Inpainting! ✨", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp),
                    enabled = !isProcessing
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.horizontalGradient(listOf(PrimaryPurple, AccentPink))),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isProcessing) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("REMOVING WATERMARK...", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EditNote, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("REMOVE WATERMARK (1 CREDIT)", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color.White)
                            }
                        }
                    }
                }

                if (cleanedVideoResult != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B5E20)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("🎉 CLEANED VIDEO READY!", fontWeight = FontWeight.Black, color = Color.White, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(cleanedVideoResult!!, fontSize = 11.sp, color = Color.LightGray)
                        }
                    }
                }
            }
        }
    }
}
