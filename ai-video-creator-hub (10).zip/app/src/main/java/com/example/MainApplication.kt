package com.example

import android.app.Application
import com.example.backend.FirebaseManager

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseManager.init(this)
    }
}
