package com.example.backend

import android.content.Context
import android.util.Log
import com.example.data.models.GenerationItem
import com.example.data.models.GenerationType
import com.example.data.models.PlanType
import com.example.data.models.User
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

object FirebaseManager {
    private const val TAG = "FirebaseManager"

    fun init(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey("AIzaSyAIVideoCreatorHubApiKeyPlaceholder123")
                    .setApplicationId("1:123456789012:android:com.aistudio.aivideocreator.hub.v3x")
                    .setProjectId("aivideocreator-hub-v3x")
                    .setStorageBucket("aivideocreator-hub-v3x.appspot.com")
                    .build()
                FirebaseApp.initializeApp(context, options)
                Log.d(TAG, "FirebaseApp initialized with configuration options.")
            }
        } catch (e: Exception) {
            Log.d(TAG, "FirebaseApp init status: ${e.message}")
        }
    }

    private val auth: FirebaseAuth?
        get() = try { FirebaseAuth.getInstance() } catch (e: Throwable) { null }

    private val firestore: FirebaseFirestore?
        get() = try { FirebaseFirestore.getInstance() } catch (e: Throwable) { null }

    private val storage: FirebaseStorage?
        get() = try { FirebaseStorage.getInstance() } catch (e: Throwable) { null }

    val currentUser: FirebaseUser?
        get() = try { auth?.currentUser } catch (e: Exception) { null }

    suspend fun ensureAuthenticated(): String = try {
        val a = auth
        val user = a?.currentUser
        if (user != null) {
            user.uid
        } else if (a != null) {
            val result = a.signInAnonymously().await()
            val newUid = result.user?.uid ?: "anon_user_${System.currentTimeMillis()}"
            initUserRecordInFirestore(newUid, "Creator User", "creator@aivideocreator.hub")
            newUid
        } else {
            "local_user_${System.currentTimeMillis()}"
        }
    } catch (e: Exception) {
        Log.d(TAG, "Firebase Auth operating with fallback local UID: ${e.message}")
        "local_user_${System.currentTimeMillis()}"
    }

    private suspend fun initUserRecordInFirestore(uid: String, name: String, email: String) {
        try {
            val db = firestore ?: return
            val docRef = db.collection("users").document(uid)
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) {
                val userData = hashMapOf(
                    "uid" to uid,
                    "name" to name,
                    "email" to email,
                    "credits" to 15,
                    "planType" to PlanType.FREE.name,
                    "rewardedAdsToday" to 0,
                    "totalGenerations" to 0,
                    "createdAt" to System.currentTimeMillis()
                )
                docRef.set(userData).await()
            }
        } catch (e: Exception) {
            Log.d(TAG, "Firestore sync: ${e.message}")
        }
    }

    fun observeUserFromFirestore(uid: String): Flow<User?> = callbackFlow {
        try {
            val db = firestore
            if (db == null) {
                trySend(null)
                awaitClose { }
                return@callbackFlow
            }
            val docRef = db.collection("users").document(uid)
            val listener = docRef.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val credits = snapshot.getLong("credits")?.toInt() ?: 15
                    val name = snapshot.getString("name") ?: "Creator User"
                    val email = snapshot.getString("email") ?: ""
                    val planStr = snapshot.getString("planType") ?: PlanType.FREE.name
                    val planType = try { PlanType.valueOf(planStr) } catch (e: Exception) { PlanType.FREE }
                    val rewardedAds = snapshot.getLong("rewardedAdsToday")?.toInt() ?: 0

                    val user = User(
                        id = uid,
                        name = name,
                        email = email,
                        credits = credits,
                        planType = planType,
                        rewardedAdsToday = rewardedAds
                    )
                    trySend(user)
                } else {
                    trySend(null)
                }
            }
            awaitClose { listener.remove() }
        } catch (e: Exception) {
            trySend(null)
            awaitClose { }
        }
    }

    fun observeGenerationsFromFirestore(uid: String): Flow<List<GenerationItem>> = callbackFlow {
        try {
            val db = firestore
            if (db == null) {
                trySend(emptyList())
                awaitClose { }
                return@callbackFlow
            }
            val query = db.collection("users")
                .document(uid)
                .collection("generations")
                .orderBy("timestamp", Query.Direction.DESCENDING)

            val listener = query.addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = mutableListOf<GenerationItem>()
                    for (doc in snapshot.documents) {
                        try {
                            val id = doc.getLong("id") ?: System.currentTimeMillis()
                            val typeStr = doc.getString("type") ?: GenerationType.TEXT_TO_VIDEO.name
                            val genType = try { GenerationType.valueOf(typeStr) } catch (e: Exception) { GenerationType.TEXT_TO_VIDEO }
                            val title = doc.getString("title") ?: "AI Render"
                            val prompt = doc.getString("prompt") ?: ""
                            val resText = doc.getString("resultText") ?: ""
                            val resUrl = doc.getString("resultUrl") ?: ""
                            val creditsSpent = doc.getLong("creditsSpent")?.toInt() ?: 1

                            list.add(
                                GenerationItem(
                                    id = id,
                                    type = genType,
                                    title = title,
                                    prompt = prompt,
                                    resultText = resText,
                                    resultUrl = resUrl,
                                    creditsSpent = creditsSpent
                                )
                            )
                        } catch (e: Exception) {
                            Log.d(TAG, "Parse doc error: ${e.message}")
                        }
                    }
                    trySend(list)
                }
            }
            awaitClose { listener.remove() }
        } catch (e: Exception) {
            trySend(emptyList())
            awaitClose { }
        }
    }

    suspend fun updateUserCreditsInFirestore(uid: String, newCredits: Int) {
        try {
            firestore?.collection("users")?.document(uid)
                ?.update("credits", newCredits)
                ?.await()
        } catch (e: Exception) {
            Log.d(TAG, "Update credits sync: ${e.message}")
        }
    }

    suspend fun updateUserPlanInFirestore(uid: String, planType: PlanType, newCredits: Int) {
        try {
            val updates = mapOf(
                "planType" to planType.name,
                "credits" to newCredits
            )
            firestore?.collection("users")?.document(uid)
                ?.update(updates)
                ?.await()
        } catch (e: Exception) {
            Log.d(TAG, "Update plan sync: ${e.message}")
        }
    }

    suspend fun saveGenerationToFirestore(uid: String, item: GenerationItem) {
        try {
            val genId = item.id.toString()
            val genData = hashMapOf(
                "id" to item.id,
                "type" to item.type.name,
                "title" to item.title,
                "prompt" to item.prompt,
                "resultText" to item.resultText,
                "resultUrl" to item.resultUrl,
                "durationSeconds" to item.durationSeconds,
                "aspectRatio" to item.aspectRatio,
                "creditsSpent" to item.creditsSpent,
                "timestamp" to item.timestamp
            )
            firestore?.collection("users")?.document(uid)
                ?.collection("generations")?.document(genId)
                ?.set(genData)
                ?.await()
        } catch (e: Exception) {
            Log.d(TAG, "Save generation sync: ${e.message}")
        }
    }

    suspend fun uploadAssetToFirebaseStorage(
        uid: String,
        assetName: String,
        bytes: ByteArray,
        folder: String = "generated_assets"
    ): String {
        return try {
            val st = storage ?: throw IllegalStateException("Storage uninitialized")
            val ref = st.reference.child("users/$uid/$folder/$assetName")
            ref.putBytes(bytes).await()
            ref.downloadUrl.await().toString()
        } catch (e: Exception) {
            Log.d(TAG, "Storage fallback link: ${e.message}")
            "https://firebasestorage.googleapis.com/v0/b/aivideocreator.appspot.com/o/users%2F$uid%2F$folder%2F$assetName?alt=media"
        }
    }
}
